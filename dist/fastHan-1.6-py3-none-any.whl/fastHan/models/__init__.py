__all__ = [
    'CharModel'
]

from .charmodel import CharModel